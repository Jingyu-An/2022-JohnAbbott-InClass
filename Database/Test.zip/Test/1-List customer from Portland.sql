/*
Test 1

Script Data : June 17, 2022
Developed by :  Jingyu An // 2228416
*/

-- 1. List customers from Portland city.

select *
from Customers
where City = 'Portland'
;