package question1;

public interface Collecable {

    public void pickUp();
    public void drop();
}
